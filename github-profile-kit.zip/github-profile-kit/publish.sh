#!/usr/bin/env bash
set -euo pipefail
# Run locally with an existing, authenticated clone of elleamyr/elleamyr.
# Usage: bash publish.sh /absolute/path/to/elleamyr
kit_dir="$(cd -- "$(dirname -- "$0")" && pwd)"
repo_dir="${1:?Usage: bash publish.sh /absolute/path/to/elleamyr}"
repo_dir="$(cd -- "$repo_dir" && pwd)"
git -C "$repo_dir" rev-parse --is-inside-work-tree >/dev/null
remote_url="$(git -C "$repo_dir" remote get-url origin)"
case "$remote_url" in
  https://github.com/elleamyr/elleamyr|https://github.com/elleamyr/elleamyr.git|git@github.com:elleamyr/elleamyr.git|ssh://git@github.com/elleamyr/elleamyr.git) ;;
  *) echo "Stopped: origin must be elleamyr/elleamyr." >&2; exit 1 ;;
esac
if [[ -n "$(git -C "$repo_dir" status --porcelain)" ]]; then
  echo "Stopped: commit or stash your existing local changes first." >&2; exit 1
fi
if [[ "$(git -C "$repo_dir" branch --show-current)" != main ]]; then
  echo "Stopped: check out main first." >&2; exit 1
fi
git -C "$repo_dir" pull --ff-only origin main
mkdir -p "$repo_dir/assets"
cp "$kit_dir/README.md" "$repo_dir/README.md"
for asset in profile-hero.svg client-experience.png impact-motion.gif talkbot-workflow.gif; do
  cp "$kit_dir/assets/$asset" "$repo_dir/assets/$asset"
done
git -C "$repo_dir" add -- README.md assets/profile-hero.svg assets/client-experience.png assets/impact-motion.gif assets/talkbot-workflow.gif
if git -C "$repo_dir" diff --cached --quiet; then echo "Profile is already up to date."; exit 0; fi
git -C "$repo_dir" commit -m "Present AI delivery, prompt engineering and client experience"
git -C "$repo_dir" push origin main
