from PIL import Image,ImageDraw,ImageFont,ImageChops
names=[('shopee','Shopee'),('monee','Monee'),('ryt','Ryt Bank'),('lazada','Lazada'),('uob','UOB'),('tiktok','TikTok'),('atome','Atome')]
im=Image.new('RGB',(1200,470),'#151c30');d=ImageDraw.Draw(im)
def f(n,b=False):
 try: return ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial'+(' Bold' if b else '')+'.ttf',n)
 except OSError: return ImageFont.truetype('DejaVuSans-Bold.ttf' if b else 'DejaVuSans.ttf',n)
d.text((36,26),'CLIENT EXPERIENCE',font=f(14,True),fill='#8be4d1');d.text((36,55),'Enterprise brands I’ve worked with',font=f(29,True),fill='#f4f4ff')
for i,(key,label) in enumerate(names):
 row=i//4; col=i%4;x=36+col*286+(143 if row else 0);y=112+row*157
 d.rounded_rectangle((x,y,x+268,y+137),radius=14,fill=('#202a42' if key=='ryt' else '#ffffff'))
 logo=Image.open('scripts/logos/'+key+'.png').convert('RGBA')
 if logo.getextrema()[3][0]<255:
  box=logo.getbbox();logo=logo.crop(box)
 else:
  rgb=logo.convert('RGB');bg=Image.new('RGB',rgb.size,rgb.getpixel((0,0)));box=ImageChops.difference(rgb,bg).getbbox();logo=logo.crop(box) if box else logo
 logo.thumbnail((192,68),Image.Resampling.LANCZOS)
 im.paste(logo,(x+(268-logo.width)//2,y+18+(68-logo.height)//2),logo)
 w=d.textlength(label,font=f(15,True));d.text((x+(268-w)/2,y+105),label,font=f(15,True),fill=('#ffffff' if key=='ryt' else '#32384a'))
d.text((36,440),'Client-facing experience across e-commerce, financial services and technology.',font=f(13),fill='#acb8d0')
im.save('assets/client-experience.png')
