from PIL import Image,ImageDraw,ImageFont
import math,os
os.makedirs('assets',exist_ok=True)
REG=os.environ.get('PROFILE_FONT','/System/Library/Fonts/Supplemental/Arial.ttf'); BOLD=os.environ.get('PROFILE_FONT_BOLD','/System/Library/Fonts/Supplemental/Arial Bold.ttf')
if not os.path.exists(REG): REG='DejaVuSans.ttf'; BOLD='DejaVuSans-Bold.ttf'
def font(n,b=False): return ImageFont.truetype(BOLD if b else REG,n)
BG='#151c30'; CARD='#202a42'; LINE='#36425f'; WHITE='#f4f4ff'; MUTED='#acb8d0'; MINT='#8be4d1'; LILAC='#c4b5fd'
# Static numbers remain readable throughout; motion traces a normalized before/after comparison.
frames=[]
for i in range(60):
 im=Image.new('RGB',(1200,360),BG);d=ImageDraw.Draw(im)
 d.text((36,23),'DELIVERY IN NUMBERS',font=font(14,True),fill=MINT)
 d.text((36,48),'Better conversations. Measurable outcomes.',font=font(27,True),fill=WHITE)
 for x in [36,420,804]: d.rounded_rectangle((x,103,x+360,306),radius=16,fill=CARD,outline=LINE)
 d.text((58,118),'50%',font=font(45,True),fill=LILAC);d.text((58,173),'fewer critical errors',font=font(19,True),fill=WHITE)
 d.text((58,201),'ByteDance · over three months',font=font(13),fill=MUTED)
 d.text((442,118),'100+',font=font(45,True),fill=MINT);d.text((442,173),'evaluation tasks / week',font=font(19,True),fill=WHITE)
 d.text((442,201),'SG · Beijing · US stakeholders',font=font(13),fill=MUTED)
 d.text((826,118),'20%',font=font(45,True),fill=LILAC);d.text((826,173),'lower greeting drop-off',font=font(19,True),fill=WHITE)
 d.text((826,201),'WIZ.AI · post-launch tuning',font=font(13),fill=MUTED)
 # Two bars: original level =100; resulting levels=50 /80.
 p=min(1,max(0,(i-4)/25));p=1-(1-p)**3
 for x,ratio in [(58,.5),(826,.8)]:
  d.rounded_rectangle((x,236,x+290,243),radius=3,fill='#49556e')
  d.rounded_rectangle((x,252,x+max(5,int(290*ratio*p)),263),radius=5,fill=MINT)
  d.text((x,276),'Original 100  /  After '+str(int(ratio*100)),font=font(12),fill=MUTED)
 for n in range(10):
  x=444+n*29;y=248
  color=MINT if n <= (i//4)%10 else '#3d4c68'
  d.rounded_rectangle((x,y,x+19,y+13),radius=4,fill=color)
 d.text((442,276),'Weekly evaluation cadence',font=font(12),fill=MUTED)
 d.text((36,327),'Reported outcomes · Bars show relative levels, with original = 100. Motion is illustrative.',font=font(12),fill=MUTED)
 frames.append(im)
frames[0].save('assets/impact-motion.gif',save_all=True,append_images=frames[1:],duration=90,loop=0,optimize=True)

# A process animation illustrates the hands-on workflow without inventing performance data.
frames=[]
labels=[('01','DISCOVER','Business goals'),('02','DESIGN','Conversation flows'),('03','PROMPT','Talkbot behaviour'),('04','EVALUATE','Test & refine'),('05','DEPLOY','Launch & improve')]
for i in range(75):
 im=Image.new('RGB',(1200,290),BG); d=ImageDraw.Draw(im)
 d.text((36,25),'FROM REQUIREMENTS TO A WORKING TALKBOT',font=font(15,True),fill=MINT)
 d.text((36,54),'Hands-on prompt engineering, with delivery ownership.',font=font(24,True),fill=WHITE)
 d.line((114,157,1084,157),fill=LINE,width=3)
 for j,(num,title,sub) in enumerate(labels):
  x=36+j*232;active=(i//15)==j
  d.rounded_rectangle((x,115,x+202,226),radius=14,fill=CARD,outline=MINT if active else LINE,width=2)
  d.text((x+16,127),num,font=font(13,True),fill=MINT if active else MUTED)
  d.text((x+16,153),title,font=font(18,True),fill=WHITE)
  d.text((x+16,185),sub,font=font(14),fill=MUTED)
  if j<4:
   d.text((x+211,147),'›',font=font(23),fill=MINT)
 d.text((36,253),'My delivery workflow · animated illustration',font=font(12),fill=MUTED)
 frames.append(im)
frames[0].save('assets/talkbot-workflow.gif',save_all=True,append_images=frames[1:],duration=100,loop=0,optimize=True)

for f in ['impact-motion.gif','talkbot-workflow.gif']:
 z=Image.open('assets/'+f);print(f,z.size,z.n_frames,os.path.getsize('assets/'+f))
